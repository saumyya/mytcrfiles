// ARRAY  - Store multiple values in a variable

// a=['yuvi','ajay','komla']
// num=[2,34,5,'ajay',2.3 ,true]
// console.log(typeof num);

// const number=[1,2,3,4,5]
// const fruits=['apples', 'oranges','pears','grapes']

// console.log(number,fruits);

// const fruits=['apples', 'oranges','pears','grapes']
// //get one value- array starts at 0
// console.log(fruits[1]);
// console.log(fruits[3]);
// //add value
// fruits[4]='blueberries'
// //add value using push
// fruits.push('strawberries')

// //add to beginning
// fruits.unshift('mangoes')



// //remove values from the last
// fruits.pop()
// console.log(fruits);
// //check if array
// console.log(Array.isArray(fruits));
// //// get index
// console.log(fruits.indexOf('oranges'));

// console.log(fruits);

//OBJECT LITERAL
// const abc={a:'priyal',b:'shivam',c:'smriti'}

// console.log(abc.c);

// const person = {
//     firstName:'ramukaka',
//     lastName:'singh',
//     id:5566,
//     fullName:function() {
//         return this.firstName +" "+ this.lastName;
//     }
// };

// console.log(person.fullName());

 const person = {
        firstName:'ramukaka',
        id:5566,
        hobbies:['singing','spleeing','Cooking','Dancing'],
        address:{
            street:'Boys street',
            city:'Chandni Chowk',
            state: 'Delhi'
        },
        fullName:function() {
            return this.firstName +" "+ this.lastName;
        }
};


// get single value
console.log(person.firstName);
console.log(person.id);
//get array value
console.log(person.hobbies[1]);

//get object value
console.log(person.address.city);

//get function value
console.log(person.fullName());

//add property
person.email='raamukaka123@gamil.com';
console.log(person);






