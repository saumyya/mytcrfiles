//==>> let ,const

// const age=25
//   age=27
//  console.log(age);

 //==>  var

//  var x=10
//  {
//    var y=20  
//  }
//  console.log(y);

// ==> let
//  let x=10
//  {
//    let y=20  
//  }
//  console.log(y);

//==> const
//  const x=10
//  {
//    const y=20  
//  }
//  console.log(y);












// datatypes

//string , number , null, boolean , undefined
// const Name ='yuvraj'
// const age=20;
// const rating =4.5;
// const is_cool=true;
// const x=null;
// const y=undefined;
// let z;

// console.log(typeof Name);
// console.log(typeof age);
// console.log(typeof rating);
// console.log(typeof is_cool);
// console.log(typeof x);
// console.log(typeof y);
// console.log(typeof z);

// "use strict";
// let a=3
// b=4
// console.log(a);

// taking input from the user
// var a=prompt("enter a no")
// var b=prompt("enter another no")
// var x=parseInt(a)
// var y=parseInt(b)
// var r=x+y
// console.log(r);

//  "use strict"
// a=20;
// var a;
// console.log(a);

