document.getElementById('demo').innerHTML="byee"
document.write('hello world')
document.write('<br>')
document.write('hello world')

// window.alert('hello')
// console.log('byee world');

// console.error('hey im an error')
console.warn('hey im an warning')