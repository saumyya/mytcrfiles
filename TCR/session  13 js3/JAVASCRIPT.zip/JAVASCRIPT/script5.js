// // Array of objects

// const todos=[
// {
//     id:1,
//     text:'is he dead',
//     isComplete:false
// },
// {
//     id:2,
//     text:'Dinner with wife',
//     isComplete:true
// },
// {
//     id:3,
//     text:'Meeting with boss',
//     isComplete:true
// },
// ];

// // Get specific object value

// console.log(todos[1].text);
// console.log(todos[2].id);

// // format as Json
// console.log(JSON.stringify(todos));



// Loops

// // for loops
// for(let i=0; i<=10; i++){
//     console.log(i);
// }


/// while loop
// let i=2
// while(i<=10){
//     console.log(`while loop number ${i}`);
//     i++;
// }

// Conditionals

// // Simple If/ Else statement

// const x='10';
// if(x===10){
//     console.log('x is 10');
// }
// else if(x>10){
// console.log('x is greater than 10');
// }
// else{
//     console.log('x is less than 10');
// }


// // Switch
// color = 'green';

// switch(color) {
//   case 'red':
//     console.log('color is red');
//     break;
//   case 'blue':
//     console.log('color is blue');
//     break;
//   default:  
//     console.log('color is not red or blue')
//     break;
// }


// // Ternary operators /Shorthand if
// const  color='red';
// const z=color === 'red' ? 10:20;
// console.log(z);

////===>> function

// x=Math.pow(3, 4)
// x=Math.sqrt(25)
// console.log(x);

// add num
// function Add(x,y){
//     console.log(x+y);
// }

// Add(2,3)

// 
// function Add(x,y,z){
//     console.log(x+y+z);
// }

// Add(2,3,6)


// x=null
// x=3
// console.log(x);


// add num
// function Add(x=3,y=3){
//     console.log(x+y);
// }

// Add(4,5)



// // ====>> Return 
// function add(x,y){
//        z= x+y
//     return z
// }
// console.log(add(3,4));



////==>> Arrow function

// const Add = (x,y)=> console.log(x+y);
// Add(2,3)
// const Add = (x,y)=> console.log(x*y);
// Add(2,3)


// also
// const Add = (x=3,y=5)=> console.log(x+y);
// Add(2,3)
