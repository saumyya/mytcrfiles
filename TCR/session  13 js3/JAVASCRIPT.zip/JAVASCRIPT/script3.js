//==> STRING
//  const Name='shivam'
//  const age= 26

 //Concatenation
// console.log('My name is '+ Name +' and I am '+ age +' year old');

// //Template literal (better)
// console.log(`My name is ${Name} ${Name} ${Name} and I am ${age} year old`);

// string methods and properties
// const s='Hello World'
//get length
// val=s.length

//Change the case
// val=s.toUpperCase()
// val=s.toLowerCase()

// //get substring
// val=s.substring(2,5).toUpperCase()
// //slice()
// val=s.slice(2,5)
// //split into arrays
// val=s.split(' ')

// //replacing
// val=s.replace('Hello','byee')

// //match
// val=s.match('or')

// val=s.charAt(1)
//  val=s.charCodeAt(1)


// console.log(val)
// console.log(val);

