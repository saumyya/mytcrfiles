/// constructor function

function Person(firstName,lastName,dob,age){
    this.firstName=firstName;
    this.lastName=lastName;
    this.dob=dob;
    this.age=age;
}

//intantiate object
const person1= new Person('ghanshyaam','sharma','3-4-1980',34)
const person2= new Person('ramukaka','patel','4-6-1990',54)

console.log(person1.dob);
console.log(person2.dob);
console.log(person2.firstName);
console.log(person2.age);

