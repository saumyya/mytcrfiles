//DOM
// console.dir(document);
// console.log(document.domain);
// console.log(document.URL);
// console.log(document.title);
// document.title=123
// console.log(document.doctype);
// console.log(document.head);
// console.log(document.body);
// console.log(document.all);
// console.log(document.all[10]);
// document.all[10].textContent='hello'
// console.log(document.forms);
// console.log(document.links);
// console.log(document.images);

//Selectors
//GET ELEMENTBY ID//
// console.log(document.getElementById('header-title'));

// var headerTitle=document.getElementById('header-title')
// console.log(headerTitle);

// headerTitle.textContent='hello'
// headerTitle.innerText='goodbye'  //it pays attention to the styling
// // console.log(headerTitle.textContent);
// // console.log(headerTitle.innerText);
// headerTitle.style.color='red'

// headerTitle.innerHTML='<h1>Goodbye';


//GET ELEMENT BY CLASS NAME//
// console.log(document.getElementsByClassName('list-group-item'));

// var item=document.getElementsByClassName('list-group-item')
// console.log(item)
// console.log(item[1]);
// item[1].textContent='hello 2'
// item[1].style.fontWeight='bold'
// item[1].style.backgroundColor='yellow'
// item[0].style.backgroundColor='yellow'
// item[2].style.backgroundColor='yellow'
// item[3].style.backgroundColor='yellow'


//error
// item.style.backgroundColor='yellow';

// for (var i=0; i<item.length; i++){
//     item[i].style.backgroundColor='yellow'
// }


//GET ELEMENT BY TAGNAME//
// var item=document.getElementsByTagName('li')
// console.log(item)
// console.log(item[1]);
// item[1].textContent='hello 2'
// item[1].style.fontWeight='bold'
// item[1].style.backgroundColor='yellow'

// for (var a=0; a<item.length; a++){
//         item[a].style.backgroundColor='yellow'
//     }


//QUERRYSELECTOR//
// var header=document.querySelector('#main-header')

// console.log(header);
// header.style.borderBottom='solid 4px red'

// var input=document.querySelector('input')
// input.value='Hello World'

// var input=document.querySelector('input[type="submit"]')
// input.value='sent'

// var item=document.querySelector('.list-group-item')
// item.style.color='red'

// var item=document.querySelector('.list-group-item:last-child')
// item.style.color='blue'

// var item=document.querySelector('.list-group-item:nth-child(2)')
// item.style.color='coral'

//QUERRYSELECTORALL//

// var title=document.querySelectorAll('.title');
// console.log(title);

// title[0].textContent='hello'


var odd =document.querySelectorAll('li:nth-child(odd)')
var even =document.querySelectorAll('li:nth-child(even)')

for (var i=0; i<odd.length; i++){
    odd[i].style.backgroundColor='yellow'
    even[i].style.backgroundColor='grey'
}



